
fetch('http://localhost:5000/api/services')
    .then(res => res.json())
    .then(data => {
        const servicesDiv = document.getElementById('services');
        data.forEach(service => {
            const div = document.createElement('div');
            div.innerHTML = `<h3>${service.name}</h3><p>${service.description}</p><p>السعر: ${service.price}$</p>`;
            servicesDiv.appendChild(div);
        });
    });
